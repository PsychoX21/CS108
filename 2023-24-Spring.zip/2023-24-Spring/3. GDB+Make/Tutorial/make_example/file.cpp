// file.cpp
#include "file.h"
#include <iostream>

void File::create() {
    std::cout << "File created: " << name << std::endl;
}
