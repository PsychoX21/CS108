#include<iostream>
void print_message_2()
{
    std::cout<<"Aola! Speaking from print-2.cpp !!!!!!!!!"<<std::endl;
    return;
}