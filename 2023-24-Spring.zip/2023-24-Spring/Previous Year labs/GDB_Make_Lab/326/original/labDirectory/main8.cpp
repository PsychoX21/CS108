#include <iostream>
#include "src/add.h"
#include "src/sub.h"
#include "src/mul.h"
#include "src/divi.h"

using namespace std;

int main(){

    cout<<add(14,56)<<"\n";
    cout<<sub(14,56)<<"\n";
    cout<<mul(14,56)<<"\n";
    cout<<divi(14,56)<<"\n";

}