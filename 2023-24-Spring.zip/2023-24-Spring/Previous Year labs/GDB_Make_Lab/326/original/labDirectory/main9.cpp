#include <iostream>
#include "src/add.h"
#include "src/sub.h"
#include "src/mul.h"
#include "src/divi.h"

using namespace std;

int main(){

    cout<<add(2,-3)<<"\n";
    cout<<sub(2,-3)<<"\n";
    cout<<mul(2,-3)<<"\n";
    cout<<divi(2,-3)<<"\n";

}