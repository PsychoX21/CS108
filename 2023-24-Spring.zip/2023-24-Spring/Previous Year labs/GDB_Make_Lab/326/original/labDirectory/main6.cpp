#include <iostream>
#include "src/add.h"
#include "src/sub.h"
#include "src/mul.h"
#include "src/divi.h"

using namespace std;

int main(){

    cout<<add(84,21)<<"\n";
    cout<<sub(84,21)<<"\n";
    cout<<mul(84,21)<<"\n";
    cout<<divi(84,21)<<"\n";

}