#include <iostream>
#include "src/add.h"
#include "src/sub.h"
#include "src/mul.h"
#include "src/divi.h"

using namespace std;

int main(){

    cout<<add(0,56)<<"\n";
    cout<<sub(0,56)<<"\n";
    cout<<mul(0,56)<<"\n";
    cout<<divi(0,56)<<"\n";

}