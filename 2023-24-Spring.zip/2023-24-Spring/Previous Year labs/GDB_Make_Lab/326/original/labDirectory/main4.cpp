#include <iostream>
#include "src/add.h"
#include "src/sub.h"
#include "src/mul.h"
#include "src/divi.h"

using namespace std;

int main(){

    cout<<add(-8,2)<<"\n";
    cout<<sub(-8,2)<<"\n";
    cout<<mul(-8,2)<<"\n";
    cout<<divi(-8,2)<<"\n";

}