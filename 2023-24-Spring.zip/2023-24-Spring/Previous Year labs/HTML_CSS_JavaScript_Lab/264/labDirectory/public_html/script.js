/* JavaScript */
/* JavaScript */
function submitMessage(){
    n=document.getElementById("Name").value;
    e=document.getElementById("Email").value;
    alert('Thank you ' + n + ' (email: ' + e + ') for your message!');
}