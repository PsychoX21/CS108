AUTHOR of the solution : Deeksha :)

Purpose of this part is given in "problemStatement.txt" in labDirectory/ folder.

To see your correctness of program, goto 264/evaluationScripts/ directory (using cd command) and run "./evaluate.sh", all the comments and evaluation will come on the 
terminal or in "evaluate.json".

If there is a permission denied problem, do "chmod +x evaluate.sh" first.

In case of any problem with autograder, please contact me.