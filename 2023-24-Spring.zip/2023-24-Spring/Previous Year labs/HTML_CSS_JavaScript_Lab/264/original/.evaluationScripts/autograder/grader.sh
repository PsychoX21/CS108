#! /bin/bash

python3 autograder.py
