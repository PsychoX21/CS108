------------------- Lab 01 (Unix) - Basic Commands --------------------

This activity is to make you familiar with the basic Unix commands.

Go through and try out (via the command line) the commands listed
in the other text file (commands.txt) present in the lab directory.
