tar -xf files.tar.gz
find bigdirectory/ -type f -name *.log > 2.txt
find bigdirectory/ -perm 777 >3.txt
find bigdirectory/ -regextype posix-extended -type f -regex .*/file_[0-9]{4}.txt >1.txt
find bigdirectory/ -type f -mtime -1 >4.txt
find bigdirectory/ -type f -size +100c -mtime +7 >5.txt
