grep -E  "[a-z]{1,}[0-9]{2} [1-4] 2[23]b[0-9]{4}@iitb\.ac\.in submission\.sh$" collect.txt > valid.txt
cut -d " " -f "1,3" valid.txt | cut -d "@" -f "1" | sort -t ' ' -k2.4,2.7n > sorted.txt
