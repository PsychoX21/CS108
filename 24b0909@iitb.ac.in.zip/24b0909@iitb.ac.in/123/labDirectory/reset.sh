# DO NOT MODIFY THIS FILE.

rm -rf testcases sorted.txt valid.txt collect.txt commands.sh

cp -r original/* .