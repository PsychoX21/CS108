# call this from initactivity when needed.
