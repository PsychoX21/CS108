#!/usr/bin/python3
import json, os
os.system('clear')

def answers_check(user_file, dataSkel):
    """ 
    to check if the file contains "hello world"
    """
    try:
        # Open and read the file
        with open(user_file, 'r') as file:
            content = file.read().strip().splitlines()

        # if len(content) != 2:
        #     raise ValueError("File content is not in the expected format with '==' delimiter.")

        file_text = content[0].lower().strip()
        if "hello world" in file_text:
            dataSkel["status"] = "pass"
            dataSkel["score"] += 1
            dataSkel["message"] = "Correct content"
        else:
            dataSkel["status"] = "fail"
            dataSkel["score"] += 0
            dataSkel["message"] = "Incorrect content!"

    except FileNotFoundError:
        print(f"Error: The file '{user_file}' was not found.")
    except ValueError as ve:
        print(f"Error: {ve}")
    except Exception as e:
        dataSkel["status"] = "fail"
        dataSkel["score"] += 0
        dataSkel["message"] = f"Key Verification Failed for {user_file}!"


# The data Structure for final results to be stored in evaluate.json
overall = {"data": []}

# YOUR Evaluation Code here
dataSkel_answers = {
            "testid": 1,
            "status": "fail",
            "score": 0,
            "maximum marks": 1,
            "message": "Autograder Failed!"
            }

# my logic for evaluation of the submissions :
answers_file = "answers.txt"

answers_check(user_file=answers_file, dataSkel=dataSkel_answers)

overall["data"].append(dataSkel_answers)


# write the results to evaluate.json with utf-8 encoding
with open('/home/.evaluationScripts/evaluate.json', 'w', encoding='utf-8') as file:
    json.dump(overall, file, indent=4)
