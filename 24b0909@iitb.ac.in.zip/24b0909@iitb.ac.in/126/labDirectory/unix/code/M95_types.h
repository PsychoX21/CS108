/** (c) 2002 by Bhaskaran Raman and Regents of the University of California */
#ifndef M95TYPES_H
#define M95TYPES_H

#include <stdlib.h>
typedef unsigned int UINT;

#ifndef _WIN32
#define bool int
#define false 0
#define true 1
#endif


#endif



