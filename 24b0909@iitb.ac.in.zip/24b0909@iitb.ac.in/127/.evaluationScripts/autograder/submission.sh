mkdir outputs
cp $(find inputs -name "*.txt") outputs

cat -n $(find outputs -name "*.txt" | sort) >cat.txt
grep -hv '^$' outputs/*.txt outputs/.*.txt | wc -l > lines.txt
