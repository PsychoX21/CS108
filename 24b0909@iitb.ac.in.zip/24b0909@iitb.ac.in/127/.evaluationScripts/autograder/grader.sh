# bash submission.sh
# apt install -y dos2unix
# dos2unix $(find . -type f)

sed 's/\r//g' submission.sh > temp
mv temp submission.sh


python3 script.py
