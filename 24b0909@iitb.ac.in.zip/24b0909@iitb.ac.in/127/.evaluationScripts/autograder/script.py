import os
import json

testcase_data = []

testcase1 = {
	"testid": 1,
	"status": "failed",
    "score": 0,
	"maximum marks": 1,
	"message": "Failed to execute Script"
}
testcase2 = {
	"testid": 2,
	"status": "failed",
    "score": 0,
	"maximum marks": 1,
	"message": ""
}
testcase3 = {
	"testid": 3,
	"status": "failed",
    "score": 0,
	"maximum marks": 1,
	"message": ""
}

list_of_files = ""

res1 = os.system("bash submission.sh")
if res1 != 0:
    testcase_data.append(testcase1)
    testcase_data.append(testcase2)
    testcase_data.append(testcase3)

else:
    # Testcase 1
    os.system("ls outputs > ls_out")
    os.system("ls correct_outputs > ls_corr_out")
    res2 = os.system("diff -Bw ls_out ls_corr_out > /dev/null")
    if res2 != 0:
        testcase1["status"] = "failed"
        testcase1["message"] = "outptus directory not as expected"
        # testcase_data.append(testcase1)
    else:
        testcase1["status"] = "success"
        testcase1["message"] = "outputs directory found as expected"
        testcase1["score"] = 1
    testcase_data.append(testcase1)

    # Testcase 2
    res3 = os.system("diff -Bw cat.txt cat_corr.txt > /dev/null")
    if res3 != 0:
        testcase2["status"] = "failed"
        testcase2["message"] = "concatenated file not as expected"
        # testcase_data.append(testcase2)
    else:
        testcase2["status"] = "success"
        testcase2["message"] = "concatenated file correct"
        testcase2["score"] = 1
    testcase_data.append(testcase2)

    res4 = os.system("diff -Bw lines.txt lines_corr.txt > /dev/null")
    if res4 != 0:
        testcase3["status"] = "failed"
        testcase3["message"] = "number of lines not as expected"
        # testcase_data.append(testcase1)
    else:
        testcase3["status"] = "success"
        testcase3["message"] = "number of lines correct"
        testcase3["score"] = 1
    testcase_data.append(testcase3)
    list_of_files = "ls_out ls_corr_out cat.txt lines.txt outputs/"
# testcase_data.append(testcase1)

overall = {"data" : testcase_data}

filename = "../evaluate.json"

with open(filename, 'w') as file:
    json.dump(overall, file, indent=4)

if list_of_files != "":
    os.system(f"rm -rf {list_of_files}")

# print(testcase_data)
        

