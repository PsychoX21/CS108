#! /bin/bash

# Actual

INSTRUCTOR_SCRIPTS="/home/.evaluationScripts"
LAB_DIRECTORY="/home/labDirectory"

# Testing 

ptcd=$(pwd)

# INSTRUCTOR_SCRIPTS="${ptcd}/.evaluationScripts"
# LAB_DIRECTORY="${ptcd}/labDirectory"

# echo "INSTRUCTOR SCRIPTS: ${INSTRUCTOR_SCRIPTS}"
# echo "LAB DIRECTORY: ${LAB_DIRECTORY}"
# echo $ptcd


cd $INSTRUCTOR_SCRIPTS

list_of_files="submission.sh"

# echo "Files: ${list_of_files}"


cp -r $LAB_DIRECTORY/submission.sh autograder/

cd ./autograder/

# echo $(ls)

chmod -R 777 $list_of_files

./grader.sh

cd ..

cat evaluate.json

rm -r $list_of_files

cd "$ptcd"

