apt install -y python3 python-is-python3
exec /bin/bash

