import os
import json

overall = {"data": []
}

data = []

test_case_num = 1
#submission_file_name = 'submission.sh'
#solution_file_name = 'solution.sh'

command = 'clear'
os.system(command)

os.system('if [ -e input/ ]; then mv input do_not_touch_input; fi')

#------------------------------test cases---------------------------

for i in range(1,test_case_num+1):

    os.system('touch test_output.txt')

    msg = ""
    total = 0
    result = {
        "testid": "1",
        "status": "success",
        "score": 0,
        "maximum marks" : 1,
        "message": ""
        }

    rval1 = os.system('ls output.zip > /dev/null 2>/dev/null')

    if rval1 == 0:
        msg = msg + str("Zip file found. ")
        os.system('unzip output.zip > /dev/null 2>/dev/null')
        rval2 = os.system('ls input/ > /dev/null 2>/dev/null')
        if rval2 == 0:
            os.system("ls --color=none -Rl input | awk -F ' ' '{if(NF > 2) {print $1}}' | sort > test_output.txt")
        else:
            msg += str("input/ not found in the output.zip. ")
            result["status"]="failed"
    else :
        msg = msg + str("Zip file does not exist. ")
        result["status"]="failed"
	

    os.system("if [ -e input/ ]; then rm -rf input; fi")

    os.system(f"cd my_testcases/{i}/; cp * ../..; cd ../..")

    os.system('grep -c "drwxr-xr-x" test_output.txt > temp.txt')

    rval3 = os.system("diff -Bw temp.txt folders_num.txt > /dev/null 2> /dev/null")

    os.system('grep -c "\-rwxr-xr-x" test_output.txt > temp.txt')

    rval4 = os.system("diff -Bw temp.txt files_num.txt > /dev/null 2> /dev/null")

    os.system("rm temp.txt")

    if rval3 == 0 and rval4 == 0:
        total=total+1
        msg = msg + str("Test Case Passed.")
    else:
        msg = msg + str("Output is not as Expected.")
        msg = msg + str(i) +"/ ."

    result["testid"] = i
    result["score"] = total
    result["message"] = msg
    data.append(result)

os.system("rm -rf test_output.txt files_num.txt folders_num.txt 2> /dev/null")

os.system('if [ -e do_not_touch_input/ ]; then mv do_not_touch_input input; fi')

overall['data'] = data
print(json.dumps(overall, indent=4))
with open('../evaluate.json', 'w') as f:
	json.dump(overall,f,indent=4)
