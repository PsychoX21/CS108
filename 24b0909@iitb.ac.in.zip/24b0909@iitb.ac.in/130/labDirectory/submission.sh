grep -i PASSED result.csv | cut -d , -f 1-2 
