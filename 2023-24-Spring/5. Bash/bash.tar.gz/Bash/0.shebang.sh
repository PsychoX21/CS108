#!/usr/bin/env python3
# Can also use shebang => /home/aria/anaconda3/bin/python3
# This is the absolute path to python3's interpreter on my laptop
# To check the path to python3's interpreter, run the command `which python3` in the terminal

print("Following is the output of the python.sh script: ")
for i in range(10):
    print(i)